# Dikenga dia Kongo — Mapa Cosmológico Bantu

Visualização interativa 3D dos 14 conceitos cosmológicos Bantu sistematizados por **Bunseki Fu-Kiau**, baseada no cosmograma sagrado *Dikenga dia Kongo* (também conhecido como *Tendwa Nza Kongo* ou *Yowa*).

## Demo

Abra `index.html` diretamente no navegador — sem dependências locais, sem servidor necessário.

Ou hospede no GitHub Pages: vá em **Settings → Pages → Branch: main → / (root)** e o mapa estará acessível em `https://<seu-usuario>.github.io/<repositorio>/`.

## Como usar

| Ação | Resultado |
|------|-----------|
| Clicar em uma esfera | Abre o conceito no painel lateral |
| Clicar na legenda | Seleciona e destaca a esfera correspondente |
| Arrastar | Gira o cosmograma |
| Scroll / pinch | Zoom in/out |

## Os 14 conceitos

| Conceito | Tradução / Significado |
|----------|----------------------|
| **DIKENGA** | O Cosmograma — Cruz Sagrada Kongo |
| **TUKULA** | Fase do Vermelho — Maturidade Plena |
| **LUVEMBA** | Fase do Branco — Transição e Ancestralidade |
| **MUSONI** | Fase do Amarelo — Nascimento e Origem |
| **KALA** | Fase do Negro — Vitalidade e Crescimento |
| **MPEMBA** | O Mundo dos Ancestrais — Terra Branca |
| **NSEKE** | O Plano Terrestre — Mundo dos Vivos |
| **KALUNGA** | A Linha das Águas — Fronteira Cósmica |
| **DIJINA** | O Nome — Identidade e Força Vital |
| **KADI** | A Lei — Justiça e Julgamento Ancestral |
| **NTANGU** | O Sol — Tempo e Ciclo Cósmico |
| **TANDU** | A Teia — Conexão e Interdependência |
| **KOLO** | O Círculo — Ciclo Eterno e Totalidade |
| **ANCESTRALIDADE** | Força dos Antepassados — Memória Viva |

## Referências

- Fu-Kiau, Bunseki. *African Cosmology of the Bântu-Kôngo* (1980)
- Fu-Kiau, Bunseki. *Self-Healing Power and Therapy* (1991)
- Fu-Kiau, Bunseki. *Simba Simbi: Hold Up That Which Holds You Up* (1994)
- Thompson, Robert Farris. *Flash of the Spirit* (1983)
- Mbiti, John. *African Religions and Philosophy* (1969)
- Tempels, Placide. *Bantu Philosophy* (1945)
- Simas & Rufino. *Fogo no Mato* (2018)
- Lopes, Nei. *Enciclopédia Brasileira da Diáspora Africana*
- Obenga, Théophile. *African Philosophy: The Pharaonic Period*
- Santos, Juana Elbein dos. *Os Nàgô e a Morte*

## Tecnologia

Arquivo HTML único com Three.js (r128) carregado via CDN. Sem frameworks, sem build, sem dependências locais.

## Licença

Conteúdo educacional de uso livre para fins não-comerciais.  
Respeite e cite as fontes acadêmicas listadas acima.
